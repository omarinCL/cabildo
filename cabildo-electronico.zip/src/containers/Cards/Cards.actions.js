export const SET_ID_TO_EDIT = 'SET_ID_TO_EDIT'

export const onSetIdToEdit = id => ({ type: SET_ID_TO_EDIT, payload: id })
